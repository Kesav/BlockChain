package com.balazsholczer.hashing;

public class App {

	public static void main(String[] args) {
		
		//System.out.println(SHA256Helper.hash(SHA256Helper.hash("Hello world!")));
		System.out.println(SHA256Helper.hash("Hello world!"));
		System.out.println(SHA256Helper.hash("Hello world!"));
		
	}
}
